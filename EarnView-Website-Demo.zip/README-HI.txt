EarnView वेबसाइट डेमो — हिंदी निर्देश
=====================================

इस ZIP में ये फाइलें हैं:
- index.html
- styles.css
- app.js

यह एक मोबाइल-फ्रेंडली static website demo है। इसे Vercel पर चलाने के लिए Node/React build की ज़रूरत नहीं है।

Vercel पर डालने का आसान तरीका:
1. ZIP को डाउनलोड करके Extract करें।
2. GitHub पर अपनी Earnview repository खोलें।
3. बेहतर है कि मौजूदा Android ऐप को सुरक्षित रखने के लिए नई repository बनाएँ, उदाहरण: earnview-website।
4. Extract की गई तीनों फाइलें (index.html, styles.css, app.js) नई repository के root में upload करें। README-HI.txt भी रख सकते हैं।
5. Vercel में Add New → Project चुनें और नई website repository import करें।
6. Framework Preset: Other चुनें।
7. Build Command खाली रखें (override न करें)।
8. Output Directory खाली रखें / default रहने दें। Root Directory में ./ रखें।
9. Deploy दबाएँ।

महत्वपूर्ण:
- मौजूदा EarnView repository Android/Kotlin ऐप है। उसे मिटाएँ या उसकी files replace न करें।
- यह अभी केवल frontend demo है। टास्क पूरे करने पर demo points ब्राउज़र के local storage में बदलते हैं।
- लॉगिन/साइनअप, असली यूज़र डेटा, एडमिन पैनल, विज्ञापन सत्यापन, सुरक्षित पॉइंट हिसाब और असली निकासी/payment अभी लागू नहीं हैं।
- वास्तविक भुगतान से पहले सुरक्षित backend, database, abuse prevention, privacy policy और payment provider integration बनाना ज़रूरी है।
- Gemini API key या कोई secret इस वेबसाइट के JavaScript में न डालें।
